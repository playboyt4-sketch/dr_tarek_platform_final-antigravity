import 'dart:convert';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'offline_drm_service.dart';

/// Top-level background message handler for Firebase Cloud Messaging.
/// Must be registered outside of any class scope.
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();

  // Handle silent remote wipe when subscription is revoked
  if (message.data['type'] == 'subscription_revoked') {
    final rawSubjectIds = message.data['subject_ids'];
    if (rawSubjectIds != null) {
      try {
        final List<dynamic> parsed = jsonDecode(rawSubjectIds as String);
        final subjectIds = parsed.whereType<String>().toList();
        final prefs = await SharedPreferences.getInstance();
        final drmService = OfflineDrmService(prefs: prefs);
        await drmService.purgeSubjects(subjectIds);
      } catch (e) {
        // Fallback: wipe all if parsing fails
        final prefs = await SharedPreferences.getInstance();
        final drmService = OfflineDrmService(prefs: prefs);
        await drmService.wipeAllOfflineData();
      }
    }
  }
}
