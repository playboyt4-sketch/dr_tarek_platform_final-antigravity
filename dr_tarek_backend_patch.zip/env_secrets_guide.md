# Environment Secrets & Deployment Configuration

## 1. Cloud Functions Environment Variables & Secrets
Run these commands in your local terminal to configure the required secrets for Bunny CDN and PDF signing:

```bash
# Set Bunny CDN Playback Template (replace with your pull zone hostname)
firebase functions:secrets:set BUNNY_PLAYBACK_URL_TEMPLATE
# Value example: https://video.bunnycdn.com/play/{video_id}?quality={quality}

# Set Bunny CDN Token Authentication Secret Key
firebase functions:secrets:set BUNNY_TOKEN_KEY
# Enter your Bunny Token Key when prompted
```

## 2. Deploy Firestore Indexes & Security Rules
```bash
# Deploy all 18 composite indexes
firebase deploy --only firestore:indexes

# Deploy locked-down security rules
firebase deploy --only firestore:rules
firebase deploy --only storage:rules
```

## 3. Deploy Cloud Functions
```bash
cd functions
npm install
npm run build
firebase deploy --only functions
```

## 4. Run the Initial Seeding Script
```bash
# In the functions directory:
npx ts-node src/scripts/seed_database.ts "010XXXXXXXX"
# (Pass Dr. Tarek's registered phone number to automatically assign Teacher role)
```
